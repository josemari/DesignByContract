java -javaagent:cofoja-1.3.jar -jar DesignByContract-1.0-SNAPSHOT.jar &
